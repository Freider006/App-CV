import 'package:flutter/material.dart';
import '../utils/app_colors.dart';

/// Reusable widget para mostrar skills
class SkillsBox extends StatelessWidget {
  const SkillsBox({
    super.key,
    required this.title,
  });

  final String title;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        color: AppColors.appPrimaryColor,
      ),
      child: Text(
        title,
        style: theme.textTheme.titleMedium?.copyWith(
          color: Colors.white, // texto en blanco para contraste
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}
