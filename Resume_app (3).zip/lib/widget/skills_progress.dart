// Widget separado y reutilizable para mostrar el progreso
import 'package:flutter/material.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';

import '../utils/app_colors.dart';

class SkillsProgressBar extends StatelessWidget {
  const SkillsProgressBar({
    super.key,
    required this.title,
    required this.progress,
  });

  final String title;
  final double progress;

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final theme = Theme.of(context);

    return Padding(
      padding: EdgeInsets.symmetric(vertical: size.height * .015),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          /// Título de la skill
          Text(
            title,
            style: theme.textTheme.titleMedium,
          ),
          const SizedBox(height: 4),

          /// Barra de progreso (con animación)
          LinearPercentIndicator(
            lineHeight: size.height * .02,
            width: size.width * .8,
            barRadius: const Radius.circular(50),
            percent: progress,
            backgroundColor: AppColors.appPrimaryColor.withOpacity(0.2),
            progressColor: AppColors.appPrimaryColor,
            animation: true,
            animationDuration: 800,
          ),
        ],
      ),
    );
  }
}
