/// Clase Skill
class Skill {
  final String name;
  final double progress;

  Skill({required this.name, required this.progress});
}

/// Modelo de datos del desarrollador
class DevDataModel {
  final String name;
  final String bio;
  final List<Skill> skillsAndProgress;
  final List<String> hobbies;

  DevDataModel({
    required this.name,
    required this.bio,
    required this.skillsAndProgress,
    required this.hobbies,
  });
}

/// Datos de ejemplo del desarrollador
class DevData {
  DevData._();

  static final devData = DevDataModel(
    name: "Freider Córdoba",
    bio: "Soy un estudiante de ingeniería en software apasionado por la "
        "tecnología y el desarrollo móvil 🚀.",
    skillsAndProgress: [
      Skill(name: "Software Engineer", progress: 0.8),
      Skill(name: "Flutter Developer", progress: 0.7),
      Skill(name: "Mobile Developer", progress: 0.6),
    ],
    hobbies: [
      "Jugar videojuegos",
      "Ver series",
      "Programar proyectos personales",
      "Escuchar música",
      "Viajar",
    ],
  );
}

/// Modelo de contacto
class Contact {
  final String name;
  final String phone;
  final String email;

  Contact({
    required this.name,
    required this.phone,
    required this.email,
  });
}

/// Solo tu contacto personal
class ContactData {
  static final contacts = [
    Contact(
      name: "Freider Córdoba",
      phone: "3137873323",
      email: "Fscm3005@gmail.com",
    ),
  ];
}
