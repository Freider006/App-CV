import 'package:flutter/material.dart';
import 'package:resume_app/view/first_view.dart';
import 'package:resume_app/view/second_view.dart';

class MainView extends StatefulWidget {
  // 👈 esta clase debe existir
  const MainView({super.key});

  @override
  State<MainView> createState() => _MainViewState();
}

class _MainViewState extends State<MainView> {
  late PageController pageController;

  @override
  void initState() {
    super.initState();
    pageController = PageController();
  }

  @override
  void dispose() {
    pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: PageView(
        controller: pageController,
        scrollDirection: Axis.vertical,
        children: [
          FirstView(pageController: pageController),
          SecondView(pageController: pageController),
        ],
      ),
    );
  }
}
