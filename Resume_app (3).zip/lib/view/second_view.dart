import 'package:flutter/material.dart';
import '../data/dev_data.dart';

class SecondView extends StatelessWidget {
  final PageController pageController;

  const SecondView({super.key, required this.pageController});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              /// 🚀 Bio
              Text("🚀 BIO", style: theme.textTheme.titleLarge),
              const SizedBox(height: 10),
              Text(
                DevData.devData.bio,
                style: theme.textTheme.bodyMedium,
              ),
              const SizedBox(height: 20),

              /// ✨ Hobbies
              Text("✨ HOBBIES", style: theme.textTheme.titleLarge),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: DevData.devData.hobbies
                    .map(
                      (hobby) => Chip(
                        label: Text(
                          hobby,
                          style: theme.textTheme.bodyMedium?.copyWith(
                            color: Colors.white,
                          ),
                        ),
                        backgroundColor: Colors.blue,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 8),
                      ),
                    )
                    .toList(),
              ),
              const SizedBox(height: 20),

              /// 📞 Contacto
              Text("📞 CONTACTO", style: theme.textTheme.titleLarge),
              const SizedBox(height: 10),
              ...ContactData.contacts.map(
                (contact) => ListTile(
                  leading: const Icon(Icons.person, color: Colors.green),
                  title: Text(contact.name, style: theme.textTheme.bodyMedium),
                  subtitle: Text(
                    "${contact.phone}\n${contact.email}",
                    style: theme.textTheme.bodySmall,
                  ),
                  isThreeLine: true,
                ),
              ),

              const SizedBox(height: 30),

              /// 🔙 Botón volver
              Center(
                child: ElevatedButton(
                  onPressed: () {
                    pageController.animateToPage(
                      0,
                      duration: const Duration(milliseconds: 500),
                      curve: Curves.easeInOut,
                    );
                  },
                  child: const Text("Volver al inicio"),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
