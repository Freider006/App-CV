// Custom class for storing app strings
class AppStrings {
  AppStrings._();

  static String profileImageUrl =
      'https://em-content.zobj.net/source/apple/279/technologist-medium-dark-skin-tone_1f9d1-1f3fe-200d-1f4bb.png';
  static const String secondScreenBio = '🚀BIO';
  static const String secondScreenHobbies = '✨HOBBIES';
  static const String secondScreenContact = '📢CONTACT';
}
