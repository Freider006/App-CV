package com.example.resume_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
