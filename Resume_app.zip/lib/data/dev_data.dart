class DevData {
  static final devData = DevDataModel(
    name: "Freider",
    skillsAndProgress: [
      Skill(name: "Software Engineer", progress: 0.8),
      Skill(name: "Flutter Developer", progress: 0.7),
      Skill(name: "Mobile Developer", progress: 0.6),
    ],
    hobbies: [
      "Jugar videojuegos",
      "Ver series",
      "Programar proyectos personales",
      "Escuchar música",
      "Viajar",
    ],
  );

  static String devBio =
      "Soy un estudiante de ingeniería en software apasionado por la tecnología y el desarrollo móvil.";
}

/// Modelo
class DevDataModel {
  final String name;
  final List<Skill> skillsAndProgress;
  final List<String> hobbies;

  DevDataModel({
    required this.name,
    required this.skillsAndProgress,
    required this.hobbies,
  });
}

/// Clase Skill
class Skill {
  final String name;
  final double progress;

  Skill({
    required this.name,
    required this.progress,
  });
}
