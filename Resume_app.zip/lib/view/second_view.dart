import 'package:flutter/material.dart';
import 'package:resume_app/data/dev_data.dart';
import 'package:resume_app/utils/app_strings.dart';

class SecondView extends StatelessWidget {
  final PageController pageController;

  const SecondView({Key? key, required this.pageController}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    ThemeData theme = Theme.of(context);

    return SafeArea(
      child: Padding(
        padding: EdgeInsets.all(size.height * 0.02),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ///  Título Bio
            Text(
              AppStrings.secondScreenBio,
              style: theme.textTheme.bodyLarge,
            ),

            const SizedBox(height: 10),

            ///  Texto Bio
            Text(
              DevData.devBio,
              style: theme.textTheme.bodyMedium,
            ),

            const SizedBox(height: 20),

            ///  Título Hobbies
            Text(
              "Mis Hobbies",
              style: theme.textTheme.bodyLarge,
            ),

            const SizedBox(height: 10),

            ///  Cajitas de hobbies
            Wrap(
              spacing: size.width * .03,
              runSpacing: size.height * .02,
              children: List.generate(
                DevData.devData.hobbies.length,
                (index) => Chip(
                  label: Text(
                    DevData.devData.hobbies[index],
                    style: theme.textTheme.bodyMedium,
                  ),
                  backgroundColor: theme.cardColor,
                ),
              ),
            ),

            const Spacer(),

            /// 🔹 Botón para volver a la primera página
            Center(
              child: ElevatedButton(
                onPressed: () {
                  pageController.animateToPage(
                    0, //  volver a la primera página
                    duration: const Duration(milliseconds: 500),
                    curve: Curves.easeInOut,
                  );
                },
                child: const Text("Volver al inicio"),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
