import 'package:flutter/material.dart';

// Importa tus utilidades y widgets personalizados
import 'package:resume_app/utils/app_colors.dart';
import 'package:resume_app/utils/app_strings.dart';
import 'package:resume_app/data/dev_data.dart';

import '../widget/skills_box.dart';
import '../widget/skills_progress.dart';

class FirstView extends StatelessWidget {
  final PageController pageController;

  const FirstView({super.key, required this.pageController});

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    ThemeData theme = Theme.of(context);

    return SafeArea(
      child: SingleChildScrollView(
        padding: EdgeInsets.all(size.width * 0.05),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            /// Botón para ir a la segunda página
            ElevatedButton(
              onPressed: () {
                pageController.animateToPage(
                  1,
                  duration: const Duration(milliseconds: 500),
                  curve: Curves.easeInOut,
                );
              },
              child: const Text("Ir a la segunda página"),
            ),

            SizedBox(height: size.height * .05),

            /// Avatar del desarrollador
            Container(
              padding: EdgeInsets.all(size.height * .01),
              decoration: BoxDecoration(
                color: theme.cardColor,
                shape: BoxShape.circle,
              ),
              child: CircleAvatar(
                radius: size.height * .12,
                backgroundColor: AppColors.appPrimaryColor,
                backgroundImage: NetworkImage(AppStrings.profileImageUrl),
              ),
            ),

            SizedBox(height: size.height * .02),

            /// Nombre del desarrollador
            Text(
              DevData.devData.name,
              style: theme.textTheme.displayLarge,
            ),

            SizedBox(height: size.height * .03),

            /// Skills en cajitas (SkillsBox)
            Wrap(
              crossAxisAlignment: WrapCrossAlignment.center,
              alignment: WrapAlignment.center,
              spacing: size.width * .03,
              runSpacing: size.height * .02,
              children: List.generate(
                DevData.devData.skillsAndProgress.length,
                (index) => SkillsBox(
                  title: DevData.devData.skillsAndProgress[index].name,
                ),
              ),
            ),

            SizedBox(height: size.height * .03),

            /// Skills con barra de progreso
            Column(
              children: List.generate(
                DevData.devData.skillsAndProgress.length,
                (index) => SkillsProgressBar(
                  title: DevData.devData.skillsAndProgress[index].name,
                  progress: DevData.devData.skillsAndProgress[index].progress,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
