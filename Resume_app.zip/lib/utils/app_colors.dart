import 'package:flutter/material.dart';

// Custom class for storing app colors
class AppColors {
  AppColors._();

  static Color appPrimaryColor = const Color(0xff4806e1);
  static Color appLightCardColor = const Color.fromARGB(255, 241, 241, 241);
  static Color appDarkCardColor = const Color.fromARGB(255, 24, 24, 24);
}
